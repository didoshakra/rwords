;(() => {
  let floatingBtn = null
  let popupHost = null
  let endMarker = null       // персистентний невидимий DOM-маркер на позиції кінця виділення
  let blockEl = null         // елемент-блок тексту (для ширини/лівого краю попапу)
  let lastSelectionText = ""
  let ignoreNextMouseUp = false
  let repositionAttached = false

  // ─── Очищення ──────────────────────────────────────────────
  function removeMarker() {
    if (endMarker && endMarker.parentNode) {
      const parent = endMarker.parentNode
      parent.removeChild(endMarker)
      parent.normalize() // зливаємо розбитий текстовий вузол назад, не лишаємо слідів
    }
    endMarker = null
  }

  function removeFloatingBtn() {
    if (floatingBtn) { floatingBtn.remove(); floatingBtn = null }
  }

  function removePopup() {
    if (popupHost) { popupHost.remove(); popupHost = null }
  }

  function cleanupAll() {
    removeFloatingBtn()
    removePopup()
    removeMarker()
    blockEl = null
    detachReposition()
  }

  // ─── Динамічне перепозиціонування при скролі/resize ───────
  // position: fixed + живе перевимірювання маркера через getBoundingClientRect()
  // на кожен scroll — це ЄДИНИЙ спосіб коректно прив'язати попап до тексту,
  // не залежний від того, чи є на сторінці CSS transform на батьківських
  // елементах (а на Next.js-сайтах він майже завжди є через анімації переходів,
  // що ламає математику "absolute + scrollY").
  function reposition() {
    if (!endMarker) return
    const endRect = endMarker.getBoundingClientRect()
    const blockRect = blockEl ? blockEl.getBoundingClientRect() : null

    const MIN_WIDTH = 280
    const MAX_WIDTH = 700

    const top = endRect.bottom + 6 // viewport-relative, БЕЗ scrollY — для position:fixed
    const left = blockRect ? blockRect.left : Math.max(12, endRect.left - 100)
    const width = blockRect ? Math.min(Math.max(blockRect.width, MIN_WIDTH), MAX_WIDTH * 2) : MIN_WIDTH

    if (floatingBtn) {
      floatingBtn.style.top = `${top}px`
      floatingBtn.style.left = `${left}px`
    }
    if (popupHost) {
      popupHost.style.top = `${top}px`
      popupHost.style.left = `${left}px`
      popupHost.style.width = `${width}px`
    }
  }

  function attachReposition() {
    if (repositionAttached) return
    window.addEventListener("scroll", reposition, { passive: true, capture: true })
    window.addEventListener("resize", reposition, { passive: true })
    repositionAttached = true
  }

  function detachReposition() {
    if (!repositionAttached) return
    window.removeEventListener("scroll", reposition, { capture: true })
    window.removeEventListener("resize", reposition)
    repositionAttached = false
  }

  // ─── Визначення позиції кінця виділення через тимчасовий маркер ──
  function insertEndMarker(range) {
    const endRange = range.cloneRange()
    endRange.collapse(false) // точка одразу після останнього символу виділення

    const marker = document.createElement("span")
    marker.style.cssText =
      "display:inline-block;width:0;height:1em;overflow:hidden;line-height:0;pointer-events:none;"

    try {
      endRange.insertNode(marker)
      return marker
    } catch (err) {
      return null
    }
  }

  // ─── Найближчий блоковий елемент-предок виділення (для ширини попапу) ──
  function getBlockElement(range) {
    let node = range.commonAncestorContainer
    if (node.nodeType === Node.TEXT_NODE) node = node.parentElement

    while (node && node !== document.body && node !== document.documentElement) {
      const style = window.getComputedStyle(node)
      const display = style.display
      if (
        (display === "block" || display === "flex" || display === "grid" || display === "list-item") &&
        node.offsetWidth > 0
      ) {
        return node
      }
      node = node.parentElement
    }
    return null
  }

  // ─── Плаваюча кнопка "+" ───────────────────────────────────
  function createFloatingBtn() {
    removeFloatingBtn()

    const btn = document.createElement("div")
    Object.assign(btn.style, {
      position: "fixed",
      minWidth: "28px",
      height: "28px",
      borderRadius: "14px",
      background: "#2563eb",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "18px",
      paddingBottom: "1px",
      fontFamily: "sans-serif",
      cursor: "pointer",
      zIndex: "2147483647",
      boxShadow: "0 2px 8px rgba(0,0,0,0.3)",
      userSelect: "none",
    })
    btn.textContent = "+"
    btn.title = "Додати до RWords"

    btn.addEventListener("mousedown", (e) => {
      e.preventDefault()
      e.stopPropagation()
      ignoreNextMouseUp = true // придушуємо mouseup, що неминуче піде слідом за цим mousedown
      openPopup()
    })

    document.body.appendChild(btn)
    floatingBtn = btn
    reposition()
  }

  // ─── Попап з перекладом ────────────────────────────────────
  function openPopup() {
    removeFloatingBtn()
    removePopup()

    const host = document.createElement("div")
    Object.assign(host.style, {
      position: "fixed",
      zIndex: "2147483647",
    })
    document.body.appendChild(host)
    popupHost = host
    reposition()

    const shadow = host.attachShadow({ mode: "open" })
    shadow.innerHTML = `
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .box {
          width: 100%;
          background: #fff;
          border-top: 3px solid #2563eb;
          box-shadow: 0 4px 16px rgba(0,0,0,0.15);
          padding: 12px 16px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          font-size: 18px;
          color: #111;
          display: flex;
          align-items: center;
          gap: 12px;
          flex-wrap: wrap;
        }
        .translation {
          flex: 1;
          color: #1e40af;
          font-weight: 600;
          min-width: 120px;
          word-break: break-word;
          line-height: 1.4;
        }
        .loading { color: #9ca3af; font-style: italic; font-weight: normal; }
        .error-msg { color: #dc2626; font-size: 14px; flex: 1; }
        .duplicate-msg { color: #d97706; font-size: 13px; width: 100%; order: 10; }
        .btns { display: flex; gap: 8px; flex-shrink: 0; }
        button {
          padding: 7px 18px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 600;
        }
        .add-btn { background: #2563eb; color: #fff; }
        .add-btn:hover:not(:disabled) { background: #1d4ed8; }
        .add-btn:disabled { background: #bfdbfe; cursor: default; }
        .force-btn { background: #f59e0b; color: #fff; display: none; }
        .force-btn:hover { background: #d97706; }
        .close-btn { background: #f1f5f9; color: #475569; }
        .close-btn:hover { background: #e2e8f0; }
      </style>
      <div class="box">
        <div class="translation loading">Перекладаю…</div>
        <div class="btns">
          <button class="add-btn" disabled>Додати</button>
          <button class="force-btn">Все одно</button>
          <button class="close-btn">✕</button>
        </div>
        <div class="duplicate-msg" style="display:none;"></div>
      </div>
    `

    const translationEl = shadow.querySelector(".translation")
    const addBtn = shadow.querySelector(".add-btn")
    const forceBtn = shadow.querySelector(".force-btn")
    const closeBtn = shadow.querySelector(".close-btn")
    const duplicateMsgEl = shadow.querySelector(".duplicate-msg")

    closeBtn.addEventListener("click", cleanupAll)
    let currentTranslation = ""

    chrome.runtime.sendMessage({ type: "GET_AUTH" }).then((auth) => {
      if (!auth?.token) {
        translationEl.classList.remove("loading")
        translationEl.classList.add("error-msg")
        translationEl.textContent = "Увійди в розширенні (натисни іконку RWords у тулбарі)."
        return
      }

      chrome.runtime.sendMessage({ type: "TRANSLATE", text: lastSelectionText }).then((res) => {
        translationEl.classList.remove("loading")
        if (!res.ok) {
          translationEl.classList.add("error-msg")
          translationEl.textContent = res.error || "Не вдалося перекласти"
          return
        }
        currentTranslation = res.translation
        translationEl.textContent = currentTranslation
        addBtn.disabled = false
      })
    })

    addBtn.addEventListener("click", () => doAddWord(false))
    forceBtn.addEventListener("click", () => doAddWord(true))

    async function doAddWord(force) {
      addBtn.disabled = true
      forceBtn.style.display = "none"
      duplicateMsgEl.style.display = "none"
      addBtn.textContent = "Додаю…"

      const res = await chrome.runtime.sendMessage({
        type: "ADD_WORD",
        word: lastSelectionText,
        translation: currentTranslation,
        pageTitle: document.title || location.hostname,
        force,
      })

      if (!res.ok) {
        translationEl.classList.add("error-msg")
        translationEl.textContent = res.error || "Помилка додавання"
        addBtn.disabled = false
        addBtn.textContent = "Додати"
        return
      }

      if (res.result.status === "duplicate") {
        addBtn.disabled = false
        addBtn.textContent = "Додати"
        duplicateMsgEl.style.display = "block"
        duplicateMsgEl.textContent = res.result.isMine
          ? `Вже є у твоєму словнику: ${res.result.existingIn}`
          : `Вже є в публічному словнику: ${res.result.existingIn}`
        forceBtn.style.display = "block"
        return
      }

      addBtn.textContent = "Додано ✓"
      addBtn.style.background = "#16a34a"
      setTimeout(cleanupAll, 1000)
    }
  }

  // ─── Виділення мишкою ──────────────────────────────────────
  document.addEventListener("mouseup", (e) => {
    if (ignoreNextMouseUp) {
      ignoreNextMouseUp = false
      return
    }
    if (floatingBtn && floatingBtn.contains(e.target)) return
    if (popupHost && popupHost.contains(e.target)) return

    const selection = window.getSelection()
    const text = selection ? selection.toString().trim() : ""

    if (!text || text.length < 2 || text.length > 2000) {
      cleanupAll()
      return
    }

    const range = selection.getRangeAt(0)

    cleanupAll() // прибираємо попередній стан перед новим виділенням

    const marker = insertEndMarker(range)
    if (!marker) return // рідкісний edge case — просто не показуємо кнопку

    endMarker = marker
    blockEl = getBlockElement(range)
    lastSelectionText = text

    attachReposition()
    createFloatingBtn()
  })

  document.addEventListener("mousedown", (e) => {
    if (popupHost && popupHost.contains(e.target)) return
    if (floatingBtn && floatingBtn.contains(e.target)) return
    cleanupAll()
  })
})()
