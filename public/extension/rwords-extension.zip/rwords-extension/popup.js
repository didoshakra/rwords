const loginView = document.getElementById("login-view")
const loggedInView = document.getElementById("logged-in-view")
const errorEl = document.getElementById("error")
const loginBtn = document.getElementById("login-btn")

async function render() {
  const auth = await chrome.runtime.sendMessage({ type: "GET_AUTH" })

  if (auth?.token) {
    loginView.style.display = "none"
    loggedInView.style.display = "block"
    document.getElementById("user-name").textContent = auth.user?.name || ""
    document.getElementById("user-email").textContent = auth.user?.email || ""
    const from = auth.settings?.fromLang || "EN"
    const to = auth.settings?.toLang || "UK"
    document.getElementById("user-langs").textContent = `Переклад: ${from} → ${to}`
  } else {
    loginView.style.display = "block"
    loggedInView.style.display = "none"
  }
}

loginBtn.addEventListener("click", async () => {
  errorEl.textContent = ""
  const email = document.getElementById("email").value.trim()
  const password = document.getElementById("password").value

  if (!email || !password) {
    errorEl.textContent = "Заповни email і пароль"
    return
  }

  loginBtn.disabled = true
  loginBtn.textContent = "Входжу…"

  const result = await chrome.runtime.sendMessage({ type: "LOGIN", email, password })

  loginBtn.disabled = false
  loginBtn.textContent = "Увійти"

  if (!result.ok) {
    errorEl.textContent = result.error
    return
  }

  await render()
})

document.getElementById("logout-btn").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "LOGOUT" })
  await render()
})

// Enter у полі пароля — логін
document.getElementById("password").addEventListener("keydown", (e) => {
  if (e.key === "Enter") loginBtn.click()
})

render()
