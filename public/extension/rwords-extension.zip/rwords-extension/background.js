const API_BASE_URL = "https://rwords.vercel.app"

async function getStoredAuth() {
  const data = await chrome.storage.local.get(["token", "user", "settings"])
  return data
}

async function handleLogin(email, password) {
  try {
    const res = await fetch(`${API_BASE_URL}/api/extension/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    })
    const data = await res.json()
    if (!res.ok) return { ok: false, error: data.error || "Помилка логіну" }

    await chrome.storage.local.set({
      token: data.token,
      user: data.user,
      settings: data.settings,
    })
    return { ok: true, user: data.user, settings: data.settings }
  } catch (err) {
    return { ok: false, error: "Немає зʼєднання з сервером" }
  }
}

async function handleLogout() {
  await chrome.storage.local.remove(["token", "user", "settings"])
  return { ok: true }
}

async function handleTranslate(text) {
  try {
    const { token, settings } = await getStoredAuth()
    if (!token) return { ok: false, error: "no_auth" }

    const res = await fetch(`${API_BASE_URL}/api/extension/translate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        text,
        fromLanguage: settings?.fromLang || "EN",
        toLanguage: settings?.toLang || "UK",
      }),
    })
    const data = await res.json()
    if (!res.ok) return { ok: false, error: data.error || "Помилка перекладу" }
    return { ok: true, translation: data.translation }
  } catch (err) {
    return { ok: false, error: "Немає зʼєднання з сервером" }
  }
}

async function handleAddWord(word, translation, pageTitle, force = false) {
  try {
    const { token } = await getStoredAuth()
    if (!token) return { ok: false, error: "no_auth" }

    const res = await fetch(`${API_BASE_URL}/api/extension/add-word`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ word, translation, pageTitle, force }),
    })
    const data = await res.json()
    if (!res.ok) return { ok: false, error: data.error || "Помилка додавання" }
    return { ok: true, result: data }
  } catch (err) {
    return { ok: false, error: "Немає зʼєднання з сервером" }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  ;(async () => {
    switch (message.type) {
      case "LOGIN":
        sendResponse(await handleLogin(message.email, message.password))
        break
      case "LOGOUT":
        sendResponse(await handleLogout())
        break
      case "GET_AUTH":
        sendResponse(await getStoredAuth())
        break
      case "TRANSLATE":
        sendResponse(await handleTranslate(message.text))
        break
      case "ADD_WORD":
        sendResponse(await handleAddWord(message.word, message.translation, message.pageTitle, message.force))
        break
      default:
        sendResponse({ ok: false, error: "unknown_message_type" })
    }
  })()
  return true // тримаємо канал відкритим для async sendResponse
})
